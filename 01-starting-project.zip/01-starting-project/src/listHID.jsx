export const listHID = [
    {
          "vendorId": "0000004c",
          "productId": "00000269",
          "usagePage": "ff00",
          "serial": "30-d9-d9-98-01-88",
          "manufacturer": "Apple",
          "product": "Magic Mouse"
      },
      {
          "vendorId": "00001050",
          "productId": "00000407",
          "usagePage": "0001",
          "serial": "",
          "manufacturer": "Yubico",
          "product": "YubiKey OTP+FIDO+CCID"
      },
      {
          "vendorId": "0x00000d8f",
          "productId": "0x00000200",
          "usagePage": "ff00",
          "serial": "30-d9-d9-98-01-88",
          "manufacturer": "Pitney Bowes",
          "product": "397-D Scale"
      },
      {
          "vendorId": "0x00008009",
          "productId": "0x00000922",
          "usagePage": "ff00",
          "serial": "30-d9-d9-98-01-88",
          "manufacturer": "DYMO",
          "product": "S250 250 lb Por"
      }
  
    ]
    